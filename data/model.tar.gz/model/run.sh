python eval.py --predict --test_file $1 --class_model rnn --result_file $2 --char
